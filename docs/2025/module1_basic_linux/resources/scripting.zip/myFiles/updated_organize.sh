#!/bin/bash

# Define extensions and their target folders
extensions="fasta fastq txt csv log"
folders="fasta fastq txt csv log other"

# Create target folders
for folder in $folders; do
  mkdir -p "$folder"
done

# Known directories to check
dirs="dir1 dir2 dir3"

# Move files by extension from current and subdirectories
for ext in $extensions; do
  # Move from current directory
  if ls *."$ext"; then
    mv *."$ext" "$ext"/
  fi

  # Move from subdirectories
  for d in $dirs; do
    if ls "$d"/*."$ext"; then
      mv "$d"/*."$ext" "$ext"/
    fi
  done
done

# Move remaining files to "other"
for d in . $dirs; do
  if ls "$d"/*.*; then
    mv "$d"/*.* other/
  fi
done

# Remove now-empty subdirectories
for d in $dirs; do
  if [ -d "$d" ]; then
    rmdir "$d"
  fi
done

# Count files in each folder
echo "📁 File counts:"
for folder in $folders; do
  count=$(ls "$folder" | wc -l)
  echo "$folder: $count files"
done

echo "✅ Files organized and extra directories removed."
