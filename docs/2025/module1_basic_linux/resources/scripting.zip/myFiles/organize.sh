#!/bin/bash

# Create target folders
mkdir -p fasta fastq txt csv log other

# Move files based on extension (from current dir and known subdirectories)
mv *.fasta fasta/
mv dir1/*.fasta dir2/*.fasta dir3/*.fasta fasta/

mv *.fastq fastq/
mv dir1/*.fastq dir2/*.fastq dir3/*.fastq fastq/

mv *.txt txt/
mv dir1/*.txt dir2/*.txt dir3/*.txt txt/

mv *.csv csv/
mv dir1/*.csv dir2/*.csv dir3/*.csv csv/

mv *.log log/
mv dir1/*.log dir2/*.log dir3/*.log log/

# Move other file types
mv *.* other/
mv dir1/*.* dir2/*.* dir3/*.* other/

# Remove unnecessary (now empty) directories
rm -r dir1 dir2 dir3

# Show how many files are in each folder
echo "📁 File counts:"
echo "fasta:  $(ls fasta | wc -l) files"
echo "fastq:  $(ls fastq | wc -l) files"
echo "txt:    $(ls txt | wc -l) files"
echo "csv:    $(ls csv | wc -l) files"
echo "log:    $(ls log | wc -l) files"
echo "other:  $(ls other | wc -l) files"

echo "✅ Files organized and extra directories removed."